#pragma once
class AFX_EXT_CLASS CJumin
{
public:
	CJumin(void);
	~CJumin(void);
	wchar_t m_szID[14];
	void setID(const wchar_t* FID, const wchar_t* LID);
	bool Validate(void);
	bool GetGender(void);
	int GetAge(void);
};

