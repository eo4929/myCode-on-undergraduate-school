
public class TimeTable {

	private String day;
	private Course[] times; // �迭 ũ�� 10�� �Ǿ�� ��
	
	TimeTable()
	{
		this.day = null;
		this.times = new Course[10];
		for(int i=0;i<10;i++) times[i] = new Course();
	}
	
	public String getDay() {return this.day;}
	public void setDay(String day) {this.day = day;}
	
	public Course getTimes(int num)
	{
		return this.times[num];
	}
	public Course[] getAllTimes()
	{
		return this.times;
	}
	public int setTimes(int num, Course c1)
	{
		if( (this.times[num]).equals(c1) )
		{
			return 0;
		}
		else if( (this.times[num]!=null) &&
				(this.times[num]).equals(c1) == false )
		{
			this.times[num] = c1;
			return -1;
		}
		else
		{
			this.times[num] = c1;
			return 1;
		}
		
	}
	
	public boolean isEmptyTime(int time)
	{
		if(this.times[time].getName()==null && 
				this.times[time].getInstructor()==null &&
				this.times[time].getRoom()==null)
			return true;
		else return false;
	}
}
