// LeftViewDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20111688P10_2.h"
#include "LeftViewDlg.h"
#include "20111688P10_2View.h"

// CLeftViewDlg

IMPLEMENT_DYNCREATE(CLeftViewDlg, CFormView)

CLeftViewDlg::CLeftViewDlg()
	: CFormView(CLeftViewDlg::IDD)
	, m_bCheckID(false)
	, m_bModify(false)
{

	m_strID = _T("");
	m_strName = _T("");
	m_strTel = _T("");
}

CLeftViewDlg::~CLeftViewDlg()
{
}

void CLeftViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_DEPT, m_cbDept);
	DDX_Text(pDX, IDC_EDIT_ID, m_strID);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
	DDX_Text(pDX, IDC_EDIT_TEL, m_strTel);
}

BEGIN_MESSAGE_MAP(CLeftViewDlg, CFormView)
	ON_BN_CLICKED(IDC_BUTTON_INSERT, &CLeftViewDlg::OnClickedButtonInsert)
	ON_BN_CLICKED(IDC_BUTTON_MODIFY, &CLeftViewDlg::OnClickedButtonModify)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, &CLeftViewDlg::OnClickedButtonDelete)
END_MESSAGE_MAP()


// CLeftViewDlg �����Դϴ�.

#ifdef _DEBUG
void CLeftViewDlg::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CLeftViewDlg::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CLeftViewDlg �޽��� ó�����Դϴ�.


void CLeftViewDlg::OnClickedButtonInsert()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMy20111688P10_2View *pView = (CMy20111688P10_2View*)this->GetNextWindow();
	int nCount = pView->GetListCtrl().GetItemCount();
	int nIndex = m_cbDept.GetCurSel();
	CString strDept,strID;
	UpdateData(TRUE);

	if( !(m_strID.IsEmpty() || m_strName.IsEmpty() || nIndex < 0 || m_strTel.IsEmpty() ))
	{
		for(int i=0; i< nCount; i++)
		{
			strID = pView->GetListCtrl().GetItemText(i,0);
			if(strID == m_strID)
			{
				m_bCheckID = TRUE;
			}
		}

		if(!m_bCheckID)
		{
			LV_ITEM lvItem;
			m_cbDept.GetLBText(nIndex,strDept);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = nCount;
			lvItem.iSubItem = 0;
			lvItem.pszText = (LPWSTR)(LPCTSTR)m_strID;
			pView->GetListCtrl().InsertItem(&lvItem);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = nCount;
			lvItem.iSubItem = 1;
			lvItem.pszText = (LPWSTR)(LPCTSTR)m_strName;
			pView->GetListCtrl().SetItem(&lvItem);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = nCount;
			lvItem.iSubItem = 2;
			lvItem.pszText = (LPWSTR)(LPCTSTR)strDept;
			pView->GetListCtrl().SetItem(&lvItem);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = nCount;
			lvItem.iSubItem = 3;
			lvItem.pszText = (LPWSTR)(LPCTSTR)m_strTel;
			pView->GetListCtrl().SetItem(&lvItem);

			m_strID.Empty();
			m_strName.Empty();
			m_strTel.Empty();
			m_cbDept.SetCurSel(-1);
			UpdateData(FALSE);
			m_bCheckID = FALSE;
		}
		else
		{
			m_bCheckID = FALSE;
			AfxMessageBox(_T("�̹� �����ϴ� �й��Դϴ�."));
		}
	}
	else
	{
		AfxMessageBox(_T("��� �׸��� �Է��ϼ���"));
	}
}


void CLeftViewDlg::OnClickedButtonModify()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMy20111688P10_2View* pView = (CMy20111688P10_2View*)this->GetNextWindow();

	int nCount = pView->GetListCtrl().GetItemCount();
	CString strDept;

	if( (pView->m_nSelectedItem < nCount) && (pView->m_nSelectedItem >= 0) )
	{
		if(!m_bModify)
		{
			m_strID = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem,0);
			m_strName = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem,1);
			strDept = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem,2);
			m_strTel = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem,3);
			UpdateData(FALSE);

			int nIndex = m_cbDept.FindStringExact(0,strDept);
			m_cbDept.SetCurSel(nIndex);
			(GetDlgItem(IDC_BUTTON_MODIFY))->SetWindowText(_T("�����Ϸ�"));
			m_bModify = TRUE;
		}
		else
		{
			m_cbDept.GetWindowText(strDept);
			UpdateData(TRUE);

			LV_ITEM lvItem;

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = pView->m_nSelectedItem;
			lvItem.iSubItem = 0;
			lvItem.pszText = (LPWSTR)(LPCTSTR)m_strID;
			pView->GetListCtrl().SetItem(&lvItem);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = pView->m_nSelectedItem;
			lvItem.iSubItem = 1;
			lvItem.pszText = (LPWSTR)(LPCTSTR)m_strName;
			pView->GetListCtrl().SetItem(&lvItem);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = pView->m_nSelectedItem;
			lvItem.iSubItem = 2;
			lvItem.pszText = (LPWSTR)(LPCTSTR)strDept;
			pView->GetListCtrl().SetItem(&lvItem);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = pView->m_nSelectedItem;
			lvItem.iSubItem = 3;
			lvItem.pszText = (LPWSTR)(LPCTSTR)m_strTel;
			pView->GetListCtrl().SetItem(&lvItem);

			(GetDlgItem(IDC_BUTTON_MODIFY))->SetWindowText(_T("����"));
			m_strID.Empty();
			m_strName.Empty();
			m_strTel.Empty();
			m_cbDept.SetCurSel(-1);
			UpdateData(FALSE);
			m_bModify = FALSE;
			pView->m_nSelectedItem = -1;
		}
	}
	else
	{
		AfxMessageBox(_T("�������� ���ų� �������� �ʾҽ��ϴ�."));
	}
}


void CLeftViewDlg::OnClickedButtonDelete()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMy20111688P10_2View* pView = (CMy20111688P10_2View*)this->GetNextWindow();
	int nCount = pView->GetListCtrl().GetItemCount();

	if( (pView->m_nSelectedItem < nCount) && (pView->m_nSelectedItem >= 0) )
	{
		pView->GetListCtrl().DeleteItem(pView->m_nSelectedItem);
		pView->m_nSelectedItem = -1;
	}
	else
	{
		AfxMessageBox(_T("������ �������� �����ϼ���"));
	}
}
