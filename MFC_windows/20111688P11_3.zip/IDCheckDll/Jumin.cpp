#include "StdAfx.h"
#include "Jumin.h"


CJumin::CJumin(void)
{
}


CJumin::~CJumin(void)
{
}


void CJumin::setID(const wchar_t* FID, const wchar_t* LID)
{
	wcscpy_s(m_szID,FID);
	wcscat_s(m_szID,LID);
}


bool CJumin::Validate(void)
{
	int nID[13];
	int nSum = 0, nRemainder = 0, nLastDigit = 0;

	for(int i=0; i< 12; i++)
	{
		nID[i] = m_szID[i] - _T('0');
		if(i >= 8)
			nSum += nID[i] * ( (i+1) % 9 + 2 );
		else
			nSum += nID[i] * ( (i+1) % 9 + 1 );
	}

	nID[12] = m_szID[12] - _T('0');
	nRemainder = nSum % 11;
	nLastDigit = (11 - nRemainder) % 10;

	if(nID[12] == nLastDigit)
		return true;
	else
		return false;
}


bool CJumin::GetGender(void)
{
	int nSex;
	nSex  = m_szID[6] - _T('0');

	if(nSex  == 1)
		return true;
	else
		return false;
}


int CJumin::GetAge(void)
{
	int nID[2], nAge;
	nID[0] = m_szID[0] - _T('0');
	nID[1] = m_szID[1] - _T('0');

	SYSTEMTIME st;
	GetSystemTime(&st);
	nAge = st.wYear - 1900 - (nID[0] * 10 + nID[1]);

	return nAge;
}
