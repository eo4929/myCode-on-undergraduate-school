// NCardListBox.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20111688P9_1.h"
#include "NCardListBox.h"
#include "20111688P9_1Dlg.h"

// CNCardListBox

IMPLEMENT_DYNAMIC(CNCardListBox, CVSListBox)

CNCardListBox::CNCardListBox()
{

}

CNCardListBox::~CNCardListBox()
{
}


BEGIN_MESSAGE_MAP(CNCardListBox, CVSListBox)
END_MESSAGE_MAP()



// CNCardListBox �޽��� ó�����Դϴ�.




void CNCardListBox::OnAfterAddItem(int nIndex)
{
	CMy20111688P9_1Dlg* pParent = (CMy20111688P9_1Dlg*)GetParent();
	pParent->AddNameCard(GetItemText(nIndex)); // ���� ���ϱ�
}


void CNCardListBox::OnSelectionChanged(void)
{
	int nItem;
	if( (nItem = GetSelItem()) < 0 )
		return ;

	CMy20111688P9_1Dlg* pParent = (CMy20111688P9_1Dlg*)GetParent();
	pParent->SelectNameCard(nItem);
}


BOOL CNCardListBox::OnBeforeRemoveItem(int nIndex)
{
	CMy20111688P9_1Dlg* pParent = (CMy20111688P9_1Dlg*)GetParent();
	pParent->DeleteNameCard( GetSelItem() );
	return TRUE;
}
