
public class Course {
	private String name; // ���� ����
	private String instructor; // ���� ����
	private String room;
	
	Course(){}
	Course(String name){
		this.name = name;
		this.instructor = null;
		this.room = null;
	}
	Course(String name,String instructor){
		this.name = name;
		this.instructor = instructor;
		this.room = null;
	}
	Course(String name,String instructor,String room){
		this.name = name;
		this.instructor = instructor;
		this.room = room;
	}
	
	public String getName() {return this.name;}
	public void setName(String name) {this.name = name;}
	public String getInstructor() {return this.instructor;}
	public void setInstructor(String instructor) {this.instructor = instructor;}
	public String getRoom() {return this.room;}
	public void setRoom(String room) {this.room = room;}
	
	public boolean equals(Course course2)
	{
		if(this == null || course2 == null )
			return false;
		
		if(this.name == null || this.instructor == null || this.room == null) // �Ǽ� ���� �ڵ� 
			return false;
		
		if( (this.name.equals(course2.name)) 
				&& (this.instructor.equals(course2.instructor)) 
				&& (this.room.equals(course2.room)))
			return true;
		else
			return false;
	}
	
	public String toString() 
	{
		return this.name+" ("+this.instructor+") - #"+this.room;
	}
	
	public static boolean isDuplicatedCourse(Course c1, Course c2)
	{
		if(c1.equals(c2))
			return false;
		else 
			return true;
	}
}
